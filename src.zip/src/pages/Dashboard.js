import React, { useEffect, useMemo, useState } from 'react';
import { supabase } from '../supabaseClient';
import { useAuth } from '../contexts/AuthContext';
import './Dashboard.css';

const METRIC_COLUMNS = [
  { key: 'team', label: 'Team' },
  { key: 'user_name', label: 'User' },
  { key: 'territory', label: 'Territory' },
  { key: 'working_days', label: 'Working Days' },
  { key: 'complete_field_days', label: 'Complete Field Days' },
  { key: 'office_work_days', label: 'Office Work Days' },
  { key: 'no_activities', label: 'No. of Activities' },
  { key: 'no_events', label: 'No. of Events' },
  { key: 'double_visit_days', label: 'Double Visit Days' },
  { key: 'coaching_days', label: 'Coaching Days' },
];

export default function Dashboard() {
  const { profile, visibleCodes, signOut } = useAuth();
  const [periods, setPeriods] = useState([]);
  const [selectedPeriod, setSelectedPeriod] = useState('');
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Load the list of available periods once.
  useEffect(() => {
    supabase
      .from('summaries')
      .select('period')
      .then(({ data, error }) => {
        if (error) {
          setError(error.message);
          return;
        }
        const unique = [...new Set((data || []).map((r) => r.period))].filter(Boolean);
        setPeriods(unique);
        if (unique.length && !selectedPeriod) setSelectedPeriod(unique[0]);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load the actual rows this person can see, for the selected period.
  useEffect(() => {
    if (!selectedPeriod || visibleCodes.length === 0) {
      setRows([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    supabase
      .from('summaries')
      .select('*')
      .eq('period', selectedPeriod)
      .in('employee_code', visibleCodes)
      .order('team', { ascending: true })
      .order('user_name', { ascending: true })
      .then(({ data, error }) => {
        if (error) setError(error.message);
        else setRows(data || []);
        setLoading(false);
      });
  }, [selectedPeriod, visibleCodes]);

  const teamCount = useMemo(
    () => new Set(rows.map((r) => r.team)).size,
    [rows]
  );

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div>
          <div className="dashboard-mark">EXCELLENCE</div>
          <h1>{roleLabel(profile?.role)} view</h1>
        </div>
        <div className="dashboard-header-right">
          <div className="dashboard-user">
            <div className="dashboard-user-name">{profile?.employee_name}</div>
            <div className="dashboard-user-role">{profile?.role} · {profile?.employee_code}</div>
          </div>
          <button className="signout-button" onClick={signOut}>Sign out</button>
        </div>
      </header>

      <div className="dashboard-toolbar">
        <label htmlFor="period">Period</label>
        <select
          id="period"
          value={selectedPeriod}
          onChange={(e) => setSelectedPeriod(e.target.value)}
        >
          {periods.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
        <div className="dashboard-stats">
          {rows.length} {rows.length === 1 ? 'person' : 'people'}
          {teamCount > 1 ? ` across ${teamCount} teams` : ''}
        </div>
      </div>

      {error && <div className="dashboard-error">Couldn't load data: {error}</div>}

      {loading ? (
        <div className="centered-message">Loading…</div>
      ) : rows.length === 0 ? (
        <div className="centered-message">
          No data yet for this period. Once a Raw Data upload runs for
          {selectedPeriod ? ` ${selectedPeriod}` : ' this period'}, it'll show up here.
        </div>
      ) : (
        <div className="table-wrap">
          <table className="summary-table">
            <thead>
              <tr>
                {METRIC_COLUMNS.map((c) => (
                  <th key={c.key}>{c.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  {METRIC_COLUMNS.map((c) => (
                    <td key={c.key}>{r[c.key] ?? '—'}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function roleLabel(role) {
  switch (role) {
    case 'MR': return 'My';
    case 'Supervisor': return "My team's";
    case 'Area Manager': return "My area's";
    case 'BLM': return "My team's";
    case 'Admin': return 'All teams';
    default: return '';
  }
}
